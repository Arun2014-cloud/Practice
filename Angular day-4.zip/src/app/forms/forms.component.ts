import { Component, OnInit } from '@angular/core';
import { CourseModel } from '../Courses/Courses.modules';
import { listOfCourses } from '../Courses/ListOfCourses.Component';
import { coursesService } from '../Services/courses.services';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {

  newCourse:CourseModel = new CourseModel();


  constructor(public service:listOfCourses) {
   

   }


   AddNewCourse(f){

this.service.AddNewCourse(this.newCourse)
    this.newCourse = new CourseModel();
    f.reset();

      }

  ngOnInit() {
  }

}
