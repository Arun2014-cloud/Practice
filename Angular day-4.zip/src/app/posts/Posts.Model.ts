export class PostModel{
   public title:string;
   public Id:number;
   public userId:number;
   public body:string;
}