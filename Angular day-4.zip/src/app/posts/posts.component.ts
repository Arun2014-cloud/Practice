import { Component, OnInit, Injectable } from '@angular/core';
import { PostService } from './Posts.Service';
import { PostModel } from './Posts.Model';

// @Injectable() 

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  TitleList:PostModel[];
  constructor(public service:PostService) { 

    //using observable

    // this.service.getAllPosts().subscribe((response)=>{
    //   this.TitleList = response;
    //   },(error)=>{
    //       console.log(error)
    //   });

//using Promises

    this.service.getAllPosts().then((response)=>{
      this.TitleList = response;
      },(error)=>{
          console.log(error)
      });
  }

  ngOnInit() {
  }

}
