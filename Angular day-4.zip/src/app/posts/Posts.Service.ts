import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { PostModel } from "./Posts.Model";


@Injectable({
    providedIn:'root'
})
export class PostService{

  

    constructor(public httpClient:HttpClient){

    }

    //using observable
    // getAllPosts(){
    //    return this.httpClient.get("https://jsonplaceholder.typicode.com/posts")

    // }
    
//using promises

getAllPosts(){
       return this.httpClient.get<PostModel[]>("https://jsonplaceholder.typicode.com/posts").toPromise();

    }

}