import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CourseModel } from '../Courses/Courses.modules';
import { listOfCourses } from '../Courses/ListOfCourses.Component';

@Component({
  selector: 'app-model-driven-form',
  templateUrl: './model-driven-form.component.html',
  styleUrls: ['./model-driven-form.component.css']
})
export class ModelDrivenFormComponent implements OnInit {

  constructor(public service:listOfCourses) {
   

   }

  courseForm:FormGroup;
  newCourse:CourseModel = new CourseModel();

  ngOnInit() {

    this.courseForm = new FormGroup({
      'name':new FormControl(this.newCourse.title,[Validators.required]),
      'price':new FormControl(this.newCourse.price),
      'quantity':new FormControl(this.newCourse.quantity),
      'duration':new FormControl(this.newCourse.duration),
      'likes':new FormControl(this.newCourse.likes),
      'rating':new FormControl(this.newCourse.rating),
      'imageUrl':new FormControl(this.newCourse.imageUrl)

    })
  }

  AddNewCourse(){
    this.service.AddNewCourse(this.courseForm.value);
    this.newCourse = new CourseModel();
    this.courseForm.reset();
  }

}
