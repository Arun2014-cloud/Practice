import { CourseModel } from "../Courses/Courses.modules";
import { coursesService } from "../Services/courses.services";
import { Injectable } from "@angular/core";

@Injectable({
    providedIn:'root'
})

export class CurrentCartService{

    constructor(public service:coursesService){
        
    }

    currentCartItems:CourseModel[]= [];

    

    AddToCart(course:CourseModel){
        this.currentCartItems.push(course);
    }

    RemoveFromCart(ID:number){
        let Index =  this.service.courses.findIndex(x =>x.id== ID)
      
        this.currentCartItems.splice(Index, 1)
    }
}