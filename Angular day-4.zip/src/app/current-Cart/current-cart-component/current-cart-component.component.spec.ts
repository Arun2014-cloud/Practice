import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentCartComponentComponent } from './current-cart-component.component';

describe('CurrentCartComponentComponent', () => {
  let component: CurrentCartComponentComponent;
  let fixture: ComponentFixture<CurrentCartComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentCartComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentCartComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
