import { DurationPipePipe } from './duration-pipe.pipe';

describe('DurationPipePipe', () => {
  it('create an instance', () => {
    const pipe = new DurationPipePipe();
    expect(pipe).toBeTruthy();
  });
});
