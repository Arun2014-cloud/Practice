import {} from '@angular/core'


export class CourseModel{

    public id:number;public title:string; public rating:number;
        public price:number;public quantity:number; public likes:number;
        public imageUrl:string; public duration:number;

  
}