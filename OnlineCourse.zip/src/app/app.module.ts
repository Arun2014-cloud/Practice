import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms'
import {CourseComponent} from './Courses/Courses.component';
import {listOfCourses} from './Courses/ListOfCourses.Component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material/';
import { DurationPipePipe } from './Pipes/duration-pipe.pipe';
import { coursesService } from './Services/courses.services';
import { CurrentCartComponentComponent } from './current-Cart/current-cart-component/current-cart-component.component';
import { CurrentCartService } from './current-Cart/current-cart.service';
import { PostsComponent } from './posts/posts.component';
import { PostService } from './posts/Posts.Service';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    listOfCourses,
    CourseComponent,
    DurationPipePipe,
    CurrentCartComponentComponent,
    PostsComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    MatCheckboxModule,
    HttpClientModule
  ],
  providers:[coursesService,CurrentCartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
