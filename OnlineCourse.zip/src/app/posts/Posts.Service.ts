import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";


@Injectable({
    providedIn:'root'
})
export class PostService{

  

    constructor(public httpClient:HttpClient){

    }

    getAllPosts(){
alert();
        this.httpClient.get("https://jsonplaceholder.typicode.com/posts").subscribe((response)=>{


        console.log(response)
        },(error)=>{
            console.log(error)
        });

    }
}