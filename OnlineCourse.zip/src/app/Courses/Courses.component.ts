import {Component, Input} from '@angular/core';
import { CourseModel } from './Courses.modules';
import { coursesService } from '../Services/courses.services';
import { CurrentCartService } from '../current-Cart/current-cart.service';

@Component({
    selector:'app-Courses',
    templateUrl:'../Courses/Courses.component.html',
    styleUrls:['../Courses/Courses.component.css']
    
})

export class CourseComponent{

    constructor(public ServiceObj
        :coursesService, public currentCartService:CurrentCartService){

    }

    @Input('courses') courses : CourseModel ;

isFree:boolean = true;
addToCart:boolean = false;
count:number=0;

AddToCart(course){
    if(this.addToCart){
        this.currentCartService.AddToCart(course);
    }else{
        this.currentCartService.RemoveFromCart(course.ID);
    }
   
}




    
}