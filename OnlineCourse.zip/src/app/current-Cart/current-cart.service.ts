import { CourseModel } from "../Courses/Courses.modules";


export class CurrentCartService{

    currentCartItems:CourseModel[]= [];

    AddToCart(course:CourseModel){
        this.currentCartItems.push(course);
    }

    RemoveFromCart(ID:number){
        let Index =  this.currentCartItems.findIndex(x =>x.ID== ID)
      
        this.currentCartItems.splice(Index, 1)
    }
}