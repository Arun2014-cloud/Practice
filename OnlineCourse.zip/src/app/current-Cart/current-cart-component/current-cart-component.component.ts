import { Component, OnInit } from '@angular/core';
import { CurrentCartService } from '../current-cart.service';

@Component({
  selector: 'app-current-cart-component',
  templateUrl: './current-cart-component.component.html',
  styleUrls: ['./current-cart-component.component.css']
})
export class CurrentCartComponentComponent implements OnInit {

  constructor( public serviceObj: CurrentCartService) { }

  ngOnInit() {

  }

}
