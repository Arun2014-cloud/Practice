let Name = "Hello";
var square = (x) => x * x;
