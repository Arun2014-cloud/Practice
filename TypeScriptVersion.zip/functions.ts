


// function Add(x:number,y:number): number|string{


//     if(x<0) 
//         return "please pass grater than zero";

//     return x+ y;
// }

// var result:number | string = Add(10,10);
// console.log(result);

//optional params


// function OptionalParams(x?:string,y?:string){
//     console.log(x, y)
// }


//default params

// function OptionalParams(x:string='Arun',y:string='Arun'){
//     console.log(x, y)
// }


// OptionalParams();
// OptionalParams(undefined,"Testtt")
// OptionalParams("Hello", "world");


//rest params

// function PrintBooks(author:string, ...title:string[]){
//     console.log(author, title);
// }

// PrintBooks("Arun", "sdhfghsd", "hdajkfhskjdfh")

//arrow functions

// var square = (x:number):number => x*x;

//Or

// var square = (x)=>{
//     return x* x;
// }

// console.log(square(10));



//interfaces

interface IEmp{
    name:string;
    salary?:number;
    getSalary?():number;
}

var emp :IEmp = {name:'Arun',salary:1000,getSalary:function(){
return this.salary;
}}

//making optional functions and params

var emp :IEmp = {name:'Arun'}