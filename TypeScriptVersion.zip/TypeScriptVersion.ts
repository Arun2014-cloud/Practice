let Name:string = "Hello";

var square= (x)=> x*x;

//by default x is type of Any, but in tsconfig if u added noImplicitAny:true then explictly we have to add x:any

// we can compile with any es version

//tsc TypeScriptVersion.ts -t "ES6"