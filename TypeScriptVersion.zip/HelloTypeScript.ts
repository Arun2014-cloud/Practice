var str = "Hello World";


var cars:string[] = ['BMW','FERRARI'];
var moreCars:Array<string> = new Array<string>('TATA','MAHENDRA');

var allCars = [...cars,...moreCars];

console.log(allCars); 

var persons = {name:'arun', city:'bang'}

var player = {...persons,runs:40000}

console.log(player, player.runs);