var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Cars = /** @class */ (function () {
    function Cars(name, speed) {
        this.name = name;
        this.speed = speed;
    }
    Cars.prototype.speedCheck = function () {
        //string interpulation
        return ("Car Name: " + this.name + "\n        Car Speed: " + this.speed);
    };
    return Cars;
}());
//extending parent clas in u r child class
var childClass = /** @class */ (function (_super) {
    __extends(childClass, _super);
    function childClass(name, speed) {
        return _super.call(this, name, speed) || this;
    }
    //override parent class method
    childClass.prototype.speedCheck = function () {
        return _super.prototype.speedCheck.call(this) + " this class speedcheck";
    };
    return childClass;
}(Cars));
// var cars:Cars = new Cars('Honda',50);
var child = new childClass('Hero', 100);
console.log(child.speedCheck());
var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.getSalarys = function () {
        return this.salarys;
    };
    return Employee;
}());
var emp = new Employee();
//enhanced Class
var enhancedClaa = /** @class */ (function () {
    function enhancedClaa(name, speed) {
        this.name = name;
        this.speed = speed;
        console.log(this.name, this.speed);
    }
    return enhancedClaa;
}());
var ec = new enhancedClaa('TATA', 200);
