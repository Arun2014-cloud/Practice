var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
var str = "Hello World";
var cars = ['BMW', 'FERRARI'];
var moreCars = new Array('TATA', 'MAHENDRA');
var allCars = __spreadArrays(cars, moreCars);
console.log(allCars);
var persons = { name: 'arun', city: 'bang' };
var player = __assign(__assign({}, persons), { runs: 40000 });
console.log(player, player.runs);
