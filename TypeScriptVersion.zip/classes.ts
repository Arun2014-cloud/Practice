class Cars{

    name:string;
    speed:number;


    constructor(name:string,speed:number){
        this.name =name;
        this.speed = speed;
    }

    speedCheck():string{

        //string interpulation
       return (`Car Name: ${this.name}
        Car Speed: ${this.speed
        }`)
    }


}


//extending parent clas in u r child class

class childClass extends Cars{

    constructor(name:string,speed:number){
        super(name,speed);
    }

    //override parent class method

    speedCheck():string{


        return super.speedCheck() +` this class speedcheck`;
    }
}

// var cars:Cars = new Cars('Honda',50);

var child = new childClass('Hero',100)
 console.log(child.speedCheck());


 //implement interfaces

 interface IEmp{

    empName:string;
    salarys:number;
    getSalarys():number;
 }


 class Employee implements IEmp{
    empName:string;
    salarys:number;
    getSalarys():number{
        return this.salarys;
    }
 }


 var emp  = new Employee();



 //enhanced Class

 class enhancedClaa{

    constructor(private name:string, private speed:number){


        console.log(this.name,this.speed)
    }


 }

 var ec = new  enhancedClaa('TATA',200);


