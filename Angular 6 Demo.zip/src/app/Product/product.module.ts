export class productModel{

    constructor(public name:string, public price:number, public image:string){


    }
}