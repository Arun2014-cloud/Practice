import { Component, Input } from '@angular/core';
import { productModel } from './product.module';

@Component({
    selector:'app-product',
   templateUrl:'../product/product.component.html'
})


export class ProductComponent {

    @Input()   productDetails:productModel ={ name:"Camera", price:50000, image:"https://images.samsung.com/is/image/samsung/in-galaxy-m30-m305f-3gb-sm-m305fskeins-185913289?$PD_GALLERY_L_SHOP_JPG$"}
}